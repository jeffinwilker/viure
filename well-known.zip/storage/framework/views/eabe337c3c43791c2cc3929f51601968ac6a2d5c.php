<?php echo e($slot); ?>

<?php /**PATH /home1/wwviur/ava.viurecosmeticos.com.br/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>